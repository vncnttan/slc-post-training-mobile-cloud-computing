
import 'package:flutter/material.dart';
const primaryColor = Color.fromRGBO(246, 244, 235, 1);
const secondaryColor = Color.fromRGBO(145, 200, 228, 1);
const fontColor = Color.fromRGBO(116, 155, 194, 1);
const buttonColor = Color.fromRGBO(70, 130, 169, 1);